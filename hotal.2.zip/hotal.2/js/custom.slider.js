
var swiper = new Swiper(".home-slider", {
    loop:true,
    effect: "coverflow",
    spaceBetween: 30,
    grabCursor: true,
    coverflowEffect: {
       rotate: 50,
       stretch: 0,
       depth: 100,
       modifier: 1,
       slideShadows: false,
    },
    autoplay: {
       delay: 4000,
       disableOnInteraction: true,
     },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    pagination: {
       el: ".swiper-pagination",
       clickable: true,
     }
 });
 
 
 
 